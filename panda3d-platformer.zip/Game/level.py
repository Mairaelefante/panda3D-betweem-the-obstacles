from direct.gui.OnscreenText import OnscreenText
from panda3d.core import TextNode

from Game.player import Player
from Game.ground_platform import GroundPlatform
from Game.Air_platform import AirPlatform
from Game.goal import Goal
from Game.hazard import Hazard


class Level:
    def __init__(self, app, parent):

        self.App = app
        self.Parent = parent

        self.Player = None

        self.GroundPlatforms = []
        self.AirPlatforms = []
        self.Hazards = []

        self.Goal = None

        self.LevelIndex = 1
        self.GameComplete = False

        self.CameraX = 0

        self.Gravity = 1800
        self.MoveSpeed = 360
        self.JumpSpeed = -760

        self.DashSpeed = 900
        self.DashDuration = 0.15

        self.DeathY = 900

        self.DeadZoneLeft = 420
        self.DeadZoneRight = 780

        self.CameraLerp = 8

        self.Keys = {
            "left": False,
            "right": False,
        }

        self._setup_input()
        self._setup_ui()

        self.load_level(1)

        self.App.taskMgr.add(
            self.update,
            "level_update"
        )

    # -------------------------------------------------
    # INPUT
    # -------------------------------------------------

    def _setup_input(self):

        self.App.accept(
            "a",
            self._set_key,
            ["left", True]
        )

        self.App.accept(
            "a-up",
            self._set_key,
            ["left", False]
        )

        self.App.accept(
            "arrow_left",
            self._set_key,
            ["left", True]
        )

        self.App.accept(
            "arrow_left-up",
            self._set_key,
            ["left", False]
        )

        self.App.accept(
            "d",
            self._set_key,
            ["right", True]
        )

        self.App.accept(
            "d-up",
            self._set_key,
            ["right", False]
        )

        self.App.accept(
            "arrow_right",
            self._set_key,
            ["right", True]
        )

        self.App.accept(
            "arrow_right-up",
            self._set_key,
            ["right", False]
        )

        self.App.accept(
            "space",
            self._jump
        )

        self.App.accept(
            "w",
            self._jump
        )

        self.App.accept(
            "shift",
            self._dash
        )

    def _set_key(self, key, value):
        self.Keys[key] = value

    # -------------------------------------------------
    # UI
    # -------------------------------------------------

    def _setup_ui(self):

        self.StatusText = OnscreenText(
            text="",
            pos=(-1.25, 0.90),
            scale=0.07,
            align=TextNode.A_left,
            mayChange=True
        )

    # -------------------------------------------------
    # LEVEL LOADING
    # -------------------------------------------------

    def clear_level(self):

        if self.Player:
            self.Player.destroy()

        for platform in self.GroundPlatforms:
            platform.destroy()

        for platform in self.AirPlatforms:
            platform.destroy()

        for hazard in self.Hazards:
            hazard.destroy()

        if self.Goal:
            self.Goal.destroy()

        self.GroundPlatforms = []
        self.AirPlatforms = []
        self.Hazards = []

        self.Goal = None
        self.Player = None

    def load_level(self, level_index):

        self.clear_level()

        self.LevelIndex = level_index

        self.GameComplete = False

        self.CameraX = 0

        self.Parent.setX(0)

        # ------------------------------------------
        # LEVEL 1
        # ------------------------------------------

        if level_index == 1:

            player_start = (70, 620)

            ground_positions = [

                (0, 688),
                (128, 688),
                (256, 688),
                (384, 688),

                (650, 688),
                (778, 688),
                (906, 688),

                (1200, 688),
                (1328, 688),
                (1456, 688),
            ]

            air_positions = [
                (500, 540),
                (980, 470),
            ]

            hazard_positions = [
                (690, 640),
            ]

            goal_position = (1500, 590)

        # ------------------------------------------
        # LEVEL 2
        # ------------------------------------------

        else:

            player_start = (70, 620)

            ground_positions = [

                (0, 688),
                (128, 688),

                (420, 688),
                (548, 688),
                (676, 688),

                (1000, 688),
                (1128, 688),
                (1256, 688),

                (1600, 688),
                (1728, 688),
            ]

            air_positions = [
                (300, 560),
                (820, 500),
                (1380, 430),
            ]

            hazard_positions = [
                (470, 640),
                (1080, 640),
            ]

            goal_position = (1760, 590)

        # ------------------------------------------
        # PLAYER
        # ------------------------------------------

        self.Player = Player(
            self.App,
            self.Parent,
            player_start[0],
            player_start[1]
        )

        # ------------------------------------------
        # GROUND
        # ------------------------------------------

        for x, y in ground_positions:

            self.GroundPlatforms.append(

                GroundPlatform(
                    self.App,
                    self.Parent,
                    x,
                    y
                )
            )

        # ------------------------------------------
        # AIR PLATFORMS
        # ------------------------------------------

        for x, y in air_positions:

            self.AirPlatforms.append(

                AirPlatform(
                    self.App,
                    self.Parent,
                    x,
                    y
                )
            )

        # ------------------------------------------
        # HAZARDS
        # ------------------------------------------

        for x, y in hazard_positions:

            self.Hazards.append(

                Hazard(
                    self.App,
                    self.Parent,
                    x,
                    y
                )
            )

        # ------------------------------------------
        # GOAL
        # ------------------------------------------

        self.Goal = Goal(
            self.App,
            self.Parent,
            goal_position[0],
            goal_position[1]
        )

        self.StatusText.setText(
            f"Level {self.LevelIndex}"
        )

    # -------------------------------------------------
    # JUMP
    # -------------------------------------------------

    def _jump(self):

        if (
            self.Player and
            self.Player.OnGround and
            not self.GameComplete
        ):

            self.Player.VelY = self.JumpSpeed

            self.Player.OnGround = False

    # -------------------------------------------------
    # DASH
    # -------------------------------------------------

    def _dash(self):

        if (
            self.Player and
            not self.Player.Dashing and
            not self.GameComplete
        ):

            self.Player.Dashing = True

            self.Player.DashTimer = self.DashDuration

            direction = 0

            if self.Keys["left"]:
                direction = -1

            elif self.Keys["right"]:
                direction = 1

            else:
                direction = self.Player.Facing

            self.Player.VelX = (
                direction * self.DashSpeed
            )

    # -------------------------------------------------
    # UPDATE
    # -------------------------------------------------

    def update(self, task):

        dt = globalClock.getDt()

        if self.GameComplete:
            return task.cont

        # Update hazards
        for hazard in self.Hazards:
            hazard.update(dt)

        # Update player
        self._update_player(dt)

        # Check collisions
        self._check_hazards()
        self._check_goal()

        # Camera
        self._update_camera(dt)

        # UI
        self._update_ui()

        return task.cont

    # -------------------------------------------------
    # PLAYER UPDATE
    # -------------------------------------------------

    def _update_player(self, dt):

        player = self.Player

        if player is None:
            return

        # DASHING
        if player.Dashing:

            player.DashTimer -= dt

            if player.DashTimer <= 0:
                player.Dashing = False

        else:

            player.VelX = 0

            if self.Keys["left"]:

                player.VelX = -self.MoveSpeed

                player.Facing = -1

            if self.Keys["right"]:

                player.VelX = self.MoveSpeed

                player.Facing = 1

        # GRAVITY
        player.VelY += (
            self.Gravity * dt
        )

        old_y = player.Y

        # HORIZONTAL MOVE
        player.set_position(
            player.X + player.VelX * dt,
            player.Y
        )

        # HORIZONTAL COLLISION
        for platform in self.GroundPlatforms:

            if player.intersects(platform):

                if player.VelX > 0:

                    player.set_position(
                        platform.left - player.Width,
                        player.Y
                    )

                elif player.VelX < 0:

                    player.set_position(
                        platform.right,
                        player.Y
                    )

        # VERTICAL MOVE
        player.set_position(
            player.X,
            player.Y + player.VelY * dt
        )

        player.OnGround = False

        # GROUND COLLISION
        for platform in self.GroundPlatforms:

            if player.intersects(platform):

                # Falling
                if player.VelY > 0:

                    player.set_position(
                        player.X,
                        platform.top - player.Height
                    )

                    player.VelY = 0

                    player.OnGround = True

                # Head hit
                elif player.VelY < 0:

                    player.set_position(
                        player.X,
                        platform.bottom
                    )

                    player.VelY = 0

        # ONE WAY PLATFORMS
        for platform in self.AirPlatforms:

            was_above = (
                old_y + player.Height
                <= platform.top
            )

            falling = player.VelY > 0

            if (
                player.intersects(platform)
                and was_above
                and falling
            ):

                player.set_position(
                    player.X,
                    platform.top - player.Height
                )

                player.VelY = 0

                player.OnGround = True

        # DEATH
        if player.Y > self.DeathY:

            player.reset_to_spawn()

    # -------------------------------------------------
    # HAZARD CHECK
    # -------------------------------------------------

    def _check_hazards(self):

        for hazard in self.Hazards:

            if (
                hazard.Active and
                self.Player.intersects(hazard)
            ):

                self.Player.reset_to_spawn()

    # -------------------------------------------------
    # GOAL CHECK
    # -------------------------------------------------

    def _check_goal(self):

        if (
            self.Goal and
            self.Player.intersects(self.Goal)
        ):

            # LEVEL 1 -> LEVEL 2
            if self.LevelIndex == 1:

                self.StatusText.setText(
                    "LEVEL COMPLETE"
                )

                self.load_level(2)

            # LEVEL 2 -> GAME COMPLETE
            else:

                self.StatusText.setText(
                    "GAME COMPLETE"
                )

                self.GameComplete = True

    # -------------------------------------------------
    # CAMERA
    # -------------------------------------------------

    def _update_camera(self, dt):

        screen_x = (
            self.Player.X - self.CameraX
        )

        target_camera_x = self.CameraX

        if screen_x > self.DeadZoneRight:

            target_camera_x = (
                self.Player.X -
                self.DeadZoneRight
            )

        elif screen_x < self.DeadZoneLeft:

            target_camera_x = (
                self.Player.X -
                self.DeadZoneLeft
            )

        # Smooth interpolation
        self.CameraX += (
            target_camera_x - self.CameraX
        ) * min(
            1,
            self.CameraLerp * dt
        )

        # Move world
        self.Parent.setX(
            -self.CameraX
        )

    # -------------------------------------------------
    # UI UPDATE
    # -------------------------------------------------

    def _update_ui(self):

        if not self.GameComplete:

            self.StatusText.setText(

                f"Level {self.LevelIndex}"
                f" | X: {self.Player.X:.1f}"
                f" | Y: {self.Player.Y:.1f}"
            )
