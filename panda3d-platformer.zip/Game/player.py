from Core.sprite_object import SpriteObject


class Player(SpriteObject):
    def __init__(self, app, parent, x: float, y: float):
        super().__init__(
            app=app,
            parent=parent,
            texture_path="assets/Character.png",
            x=x,
            y=y,
            width=72,
            height=72,
            sort=5
        )


        self.SpawnX = x
        self.SpawnY = y

        self.VelX = 0
        self.VelY = 0

        self.OnGround = 0
        self.Dashing = False
        self.DashTimer = 0
        self.Facing = 1



    def reset_to_spawn(self):
        self.set_position(self.SpawnX, self.SpawnY)
        self.VelX = 0
        self.VelY = 0
        self.OuGround = False
        self.Dashing = False
        self.DashTimer = 0
        self.Facing = 1


        
