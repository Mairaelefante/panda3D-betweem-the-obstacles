from Core.sprite_object import SpriteObject


class AirPlatform(SpriteObject):
    def __init__(self, app, parent, x: float, y: float):
        super().__init__(
            app=app,
            parent=parent,
            texture_path="assets/AirPlatform.png",
            x=x,
            y=y,
            width=128,
            height=24,
            sort=9
        )
