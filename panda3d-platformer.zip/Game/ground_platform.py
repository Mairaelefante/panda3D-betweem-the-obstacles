from Core.sprite_object import SpriteObject


class GroundPlatform(SpriteObject):
    def __init__(self, app, parent, x: float, y: float):
        super().__init__(
            app=app,
            parent=parent,
            texture_path="assets/GroundPlatform.png",
            x=x,
            y=y,
            width=128,
            height=32,
            sort=10
        )