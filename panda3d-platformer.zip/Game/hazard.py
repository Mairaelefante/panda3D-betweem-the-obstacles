from Core.sprite_object import SpriteObject


class Hazard(SpriteObject):
    def __init__(self, app, parent, x, y):
        super().__init__(
            app=app,
            parent=parent,
            texture_path="assets/Physical Obstacle Off.png",
            x=x,
            y=y,
            width=96,
            height=48,
            sort=8
        )

        # OFF at start
        self.Active = False

        # Timer
        self.Timer = 0

        # Switch every 1.2 seconds
        self.SwitchInterval = 1.2

        # Load textures
        self.OffTexture = self.App.loader.loadTexture(
            "assets/Physical Obstacle Off.png"
        )

        self.OnTexture = self.App.loader.loadTexture(
            "assets/Physical Obstacle On.png"
        )

    def update(self, dt):

        # Increase timer
        self.Timer += dt

        # Time to switch?
        if self.Timer >= self.SwitchInterval:

            # Reset timer
            self.Timer = 0

            # Toggle ON/OFF
            self.Active = not self.Active

            # Change texture
            if self.Active:
                self.Node.setTexture(self.OnTexture, 1)

            else:
                self.Node.setTexture(self.OffTexture, 1)

