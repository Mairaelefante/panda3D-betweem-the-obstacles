from Core.sprite_object import SpriteObject


class Goal(SpriteObject):
    def __init__(self, app, parent, x: float, y: float):
        super().__init__(
            app=app,
            parent=parent,
            texture_path="assets/Portal.png",
            x=x,
            y=y,
            width=72,
            height=96,
            sort=7
        )
