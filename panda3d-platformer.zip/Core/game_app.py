from direct.showbase.ShowBase import ShowBase
from panda3d.core import WindowProperties
from Game.level import Level


class GameApp(ShowBase):
    def __init__(self):
        ShowBase.__init__(self)

        self.World = None
        self.Level = None

        self._setup_window()
        self._setup_render()
        self._create_world()
        self._create_level()

    def _setup_window(self):
        props = WindowProperties()
        props.setTitle("Panda 2D Simple Platformer")
        props.setSize(1280, 720)
        self.win.requestProperties(props)

    def _setup_render(self):
        self.disableMouse()
        self.setBackgroundColor(0.45, 0.62, 0.90, 1.0)

    def _create_world(self):
        self.World = self.pixel2d.attachNewNode("World")

    def _create_level(self):
        self.Level = Level(self, self.World)