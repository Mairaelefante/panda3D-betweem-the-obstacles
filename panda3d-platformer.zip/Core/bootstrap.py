def hello():
    print("Panda bootstrap loaded.")