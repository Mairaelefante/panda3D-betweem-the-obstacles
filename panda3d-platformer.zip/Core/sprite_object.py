from panda3d.core import CardMaker


class SpriteObject:
    def __init__(
        self,
        app,
        parent,
        texture_path,
        x,
        y,
        width,
        height,
        sort=0
    ):
        self.App = app
        self.Parent = parent

        self.X = x
        self.Y = y

        self.Width = width
        self.Height = height

        # Create rectangle geometry
        card = CardMaker("sprite")

        # Rectangle size
        card.setFrame(0, width, 0, height)

        # Create node
        self.Node = parent.attachNewNode(card.generate())

        # Draw order
        self.Node.setBin("fixed", sort)

        # Disable lighting
        self.Node.setLightOff(1)

        # Load texture
        texture = self.App.loader.loadTexture(texture_path)
        self.Node.setTexture(texture, 1)

        # Set initial position
        self.set_position(x, y)

    # ----------------------------
    # POSITION
    # ----------------------------

    def set_position(self, x, y):
        self.X = x
        self.Y = y

        # Panda3D:
        # X = horizontal
        # Z = vertical in our 2D setup
        self.Node.setPos(x, 0, -y)

    def move_by(self, dx, dy):
        self.set_position(
            self.X + dx,
            self.Y + dy
        )

    # ----------------------------
    # COLLISION HELPERS
    # ----------------------------

    @property
    def left(self):
        return self.X

    @property
    def right(self):
        return self.X + self.Width

    @property
    def top(self):
        return self.Y

    @property
    def bottom(self):
        return self.Y + self.Height

    # ----------------------------
    # RECTANGLE COLLISION
    # ----------------------------

    def intersects(self, other):
        return (
            self.left < other.right and
            self.right > other.left and
            self.top < other.bottom and
            self.bottom > other.top
        )

    # ----------------------------
    # DESTROY
    # ----------------------------

    def destroy(self):
        if self.Node:
            self.Node.removeNode()
            self.Node = None
